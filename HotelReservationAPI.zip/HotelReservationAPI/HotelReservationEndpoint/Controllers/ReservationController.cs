﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.DTOs.Response;
using HotelReservation.Core.Interfaces.Services;
using HotelReservation.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace HotelReservationEndpoint.Controllers
{
    [Authorize(Roles ="User,Admin")]
    public class ReservationController : Controller
    {
        private readonly IReservationService _reservationService;
        public ReservationController(IReservationService reservationService) {
            _reservationService= reservationService;
        }
        [HttpGet]
        [Route("GetReservations")]
        public List<ReservationDTO> GetReservations()
        {
            List < ReservationDTO > reservationDTOs = new List<ReservationDTO>();
            try
            {
                reservationDTOs = _reservationService.GetReservations();
                return reservationDTOs;
            }
            catch (ApplicationException ex)
            {
                throw new Exception(ex.Message);
            }
        }

         
        [HttpPost("CreateReservation")]
        public ResponseBaseDTO CreateReservation([FromBody] ReservationDTO reservationDTO)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            try
            {
                responseBaseDTO= _reservationService.CreateReservation(reservationDTO);
                return responseBaseDTO;
            }
            catch (ApplicationException ex)
            {
                responseBaseDTO.Message = ex.Message;
                responseBaseDTO.StatusCode = System.Net.HttpStatusCode.InternalServerError;
                return responseBaseDTO;
            }
        }
        [HttpPut("UpdateReservation/{ReservationId}")]
        public ResponseBaseDTO UpdateReservation(string ReservationId, [FromBody] ReservationDTO reservationDTO)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            try
            {
                responseBaseDTO = _reservationService.UpdateReservation(ReservationId,reservationDTO);
                return responseBaseDTO;
            }
            catch (ApplicationException ex)
            {
                responseBaseDTO.Message = ex.Message;
                responseBaseDTO.StatusCode = System.Net.HttpStatusCode.InternalServerError;
                return responseBaseDTO;
            }
        }

        [HttpGet("GetUserReservation/{UserId}")]
        public List<ReservationVMDTO> GetUserReservation(string UserId)
        {
            List<ReservationVMDTO> reservationVMDTO = new List<ReservationVMDTO>();
            try
            {
                reservationVMDTO= _reservationService.GetReservationsByCustomerId(UserId);
                return reservationVMDTO;
            }
            catch (ApplicationException ex)
            {
                throw new Exception(ex.Message);
            }
        }


    }

}

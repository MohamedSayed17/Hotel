﻿ using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelReservationEndpoint.Controllers
{
   
    [Authorize (Roles ="Admin,User")]
    public class CustomerController : Controller
    {
        private readonly ICustomerService _CustomerService;
        public CustomerController(ICustomerService CustomerService)
        {
            _CustomerService = CustomerService;
        }
        [HttpGet("GetCustomers")]
        public List<CustomerDTO> GetCustomers()
        {
            List<CustomerDTO> customerDTOs = new List<CustomerDTO>();
            try {
                customerDTOs = _CustomerService.GetCustomers();
            }
            catch(Exception ex) {
                throw new Exception(ex.Message);
            }
            return customerDTOs;
        }
    }
}

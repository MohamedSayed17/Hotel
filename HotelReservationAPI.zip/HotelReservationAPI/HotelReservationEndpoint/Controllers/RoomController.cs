﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelReservationEndpoint.Controllers
{
   
    [Authorize(Roles ="Admin,User")]
    public class RoomController : Controller
    {
        private readonly IRoomService _roomService;
        public RoomController(IRoomService roomService)
        {
            _roomService = roomService;
        }
        [HttpGet("GetRooms")]
        public List<RoomDTO> GetRooms()
        {
            List<RoomDTO> roomDTOs = new List<RoomDTO>();

            try {
                roomDTOs=_roomService.GetAllRooms();

            }
            catch(Exception ex) {
                throw new Exception(ex.Message);
            }
            return roomDTOs;
        }
    }
}

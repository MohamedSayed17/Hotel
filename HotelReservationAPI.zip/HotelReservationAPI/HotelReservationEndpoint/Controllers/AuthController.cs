﻿using HotelReservation.Core;
using HotelReservation.Core.DTOs.Auth;
using HotelReservation.Core.Interfaces.Services;
using HotelReservation.Infrastructure.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelReservationEndpoint.Controllers
{
    
    public class AuthController : Controller
    {
          private readonly IAuthService _authService;
        public AuthController(IAuthService authService)
        {
              _authService=authService;
        }

        [HttpPost("register")]
        [Authorize(Roles ="Admin")]
        public async Task<ActionResult> Registerasync([FromBody] RegisterModelDTO model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = await _authService.Register(model);
 
            //if (!AddRoleResult.IsAuthenticated)
            //{
            //    return BadRequest(result.Message);
            //}

            return Ok(result);
        }
        [HttpPost("Login")] 
        public async Task<ActionResult> GenerateTokenasync([FromBody] TokenRequestModelDTO model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = await _authService.GetToken(model);
            if (!result.IsAuthenticated)
            {
                return BadRequest(result.Message);
            }

            return Ok(result);
        }

    }
}

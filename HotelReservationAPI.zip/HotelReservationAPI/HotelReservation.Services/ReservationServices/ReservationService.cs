﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.DTOs.Response;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Services.ReservationServices
{
    public class ReservationService : IReservationService
    {
        private readonly IReservationRepository _reservationRepository;
        public ReservationService(IReservationRepository reservationRepository)
        {
            _reservationRepository = reservationRepository;
        }

        public ResponseBaseDTO CreateReservation(ReservationDTO reservation)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            responseBaseDTO= _reservationRepository.CreateReservation(reservation);
            return responseBaseDTO;
        }

        public void DeleteReservation(string id)
        {
            _reservationRepository.DeleteReservation(id);
        }

        public ResponseBaseDTO UpdateReservation(string id, ReservationDTO reservationDTO)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            responseBaseDTO=_reservationRepository.UpdateReservation(id, reservationDTO);
            return responseBaseDTO;
        }

        public List<ReservationVMDTO> GetReservationsByCustomerId(string customerId)
        {
            return _reservationRepository.GetReservationsByCustomerId(customerId);
        }

        public List<ReservationDTO> SearchReservations(string title)
        {
            throw new NotImplementedException();
        }

        public List<ReservationDTO> GetReservations()
        {
            return _reservationRepository.GetReservations();
        }
    }
}

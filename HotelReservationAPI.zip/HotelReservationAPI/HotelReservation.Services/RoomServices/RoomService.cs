﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.DTOs.Response;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Services.RoomServices
{
    public class RoomService :IRoomService
    {
        private readonly IRoomRepository _roomRepository;
        public RoomService(IRoomRepository roomRepository)
        {
            _roomRepository = roomRepository;
        }

        public List<RoomDTO> GetAllRooms()
        {
            return _roomRepository.GetAllRooms();
        }
    }
}

﻿
using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.DTOs.Response;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Services.CustomerServices
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _CustomerRepository;
        public CustomerService(ICustomerRepository CustomerRepository)
        {
            _CustomerRepository = CustomerRepository;
        }
        public List<CustomerDTO> GetCustomers()
        {
            List<CustomerDTO> customerDTOs = new List<CustomerDTO>();
            customerDTOs = _CustomerRepository.GetCustomers();
            return customerDTOs;
        }
    }
}

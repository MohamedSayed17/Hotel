﻿using HotelReservation.Core.DTOs.Auth;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Services.Auth
{
    
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository _authRepository;
        public AuthService(IAuthRepository authRepository)
        {
            _authRepository=authRepository;
        }
        public Task AddRole(string UserName, string Role)
        {
            return _authRepository.AddRoleAsync(UserName, Role);
        }

        public Task<AuthModelDTO> GetToken(TokenRequestModelDTO model)
        {
           return _authRepository.GetTokenAsync(model);
        }

        public Task<AuthModelDTO> Register(RegisterModelDTO model)
        {
            return _authRepository.RegisterAsync(model);
        }

        Task IAuthService.AddRole(string UserName, string Role)
        {
            throw new NotImplementedException();
        }
    }
}

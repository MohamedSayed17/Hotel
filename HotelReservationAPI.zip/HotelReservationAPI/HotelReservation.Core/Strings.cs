﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core
{
    public static class Strings
    {
        public static readonly string Past = "Past";
        public static readonly string Upcoming = "Upcoming";

        public static readonly string UserRole = "User";

        public static readonly string AssignRoleMessage = "Assigned Role Successfully";
    }
}

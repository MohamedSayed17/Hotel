﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.DTOs.Reservation
{
    public class ReservationDTO
    {
        public string ReservationId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string CustomerId { get; set; }
        public string RoomId { get; set; }
        public  CustomerDTO Customer { get; set; }
     }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.DTOs.Reservation
{
    public class RoomDTO
    {
        public string RoomId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int RoomNumber { get; set; }

        public int RoomDetailsId { get; set; }
        public RoomDetailsDTO RoomDetailsDTO { get; set; }
    }
}

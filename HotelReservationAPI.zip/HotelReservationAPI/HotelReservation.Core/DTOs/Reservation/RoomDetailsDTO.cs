﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.DTOs.Reservation
{
    public class RoomDetailsDTO
    {
        public string RoomDetailsId { get; set; }
        public string Description { get; set; }
        public string Address { get; set; }
        public string RoomType { get; set; }
    }
}

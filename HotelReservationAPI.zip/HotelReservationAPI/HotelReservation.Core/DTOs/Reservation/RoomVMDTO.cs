﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.DTOs.Reservation
{
    public class RoomVMDTO
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int RoomNumber { get; set; }
    }
}

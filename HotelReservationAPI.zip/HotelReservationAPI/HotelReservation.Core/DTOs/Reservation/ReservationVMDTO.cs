﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.DTOs.Reservation
{
    public class ReservationVMDTO
    { 
        public string Status { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string RoomTitle { get; set; }
        public int RoomNumber{ get; set; }
        public string RoomDescription { get; set; }
        public string RoomType { get; set; } 
    }
}

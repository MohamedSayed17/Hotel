﻿using HotelReservation.Core.DTOs.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Repositories
{
    public interface IAuthRepository
    {
       
        Task<AuthModelDTO> RegisterAsync(RegisterModelDTO model);
        Task<AuthModelDTO> GetTokenAsync(TokenRequestModelDTO model);
        Task<string> AddRoleAsync(string UserName, string Role);
    }
}

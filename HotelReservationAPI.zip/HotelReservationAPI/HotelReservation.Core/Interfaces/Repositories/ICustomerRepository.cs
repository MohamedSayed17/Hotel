﻿ using HotelReservation.Core.DTOs.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Repositories
{
    public interface ICustomerRepository
    {
        List<CustomerDTO> GetCustomers();
    }
}

﻿using HotelReservation.Core.DTOs.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Repositories
{
    public interface IRoomRepository
    {
       public RoomDTO GetRoomIDByRoomNumer(int roomNumer); 
       public List<RoomDTO> GetAllRooms();
    }
}

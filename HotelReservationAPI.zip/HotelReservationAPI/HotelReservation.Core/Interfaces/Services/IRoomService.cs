﻿using HotelReservation.Core.DTOs.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Services
{
    public interface IRoomService
    {
        public List<RoomDTO> GetAllRooms();

    }
}

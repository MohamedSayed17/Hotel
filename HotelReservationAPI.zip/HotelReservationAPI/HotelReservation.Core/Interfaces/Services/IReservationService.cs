﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.DTOs.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Services
{
    public interface IReservationService
    {
        List<ReservationVMDTO> GetReservationsByCustomerId(string customerId);
        List<ReservationDTO> GetReservations();
        ResponseBaseDTO CreateReservation(ReservationDTO reservation);
        ResponseBaseDTO UpdateReservation(string id,ReservationDTO reservationDTO);
        List<ReservationDTO> SearchReservations(string title);
        void DeleteReservation(string id);
    }
}

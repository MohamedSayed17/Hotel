﻿using HotelReservation.Core.DTOs.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Core.Interfaces.Services
{
    public interface IAuthService
    {
        Task<AuthModelDTO> Register(RegisterModelDTO model);
        Task<AuthModelDTO> GetToken(TokenRequestModelDTO model);
        Task AddRole(string UserName,string Role);
    }
}

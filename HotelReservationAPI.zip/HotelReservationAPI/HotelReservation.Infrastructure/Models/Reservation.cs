﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Infrastructure.Models
{
    [Table("Reservation")]
    public  class Reservation
    {
        [Key]
        public string ReservationId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string CustomerId { get; set; }
        public string RoomId { get; set; }

        public virtual Customer Customer { get; set; }
         
    }
}

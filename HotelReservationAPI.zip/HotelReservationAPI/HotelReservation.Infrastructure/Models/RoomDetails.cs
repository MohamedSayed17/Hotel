﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Infrastructure.Models
{
     [Table("RoomDetails")]
    public class RoomDetails
    {
        [Key]
        public string RoomDetailsId { get; set; }
        public string Description { get; set; }
        public string Address { get; set; }
        public string RoomType { get; set; }
        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; }
    }
}

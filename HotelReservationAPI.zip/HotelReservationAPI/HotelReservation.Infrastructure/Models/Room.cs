﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Infrastructure.Models
{
     [Table("Room")]
    public class Room
    {
        [Key]
        public string RoomId { get; set; }
        public string Title { get; set; }
        public int RoomNumber { get; set; }
        public string Description { get; set; }
        public int RoomDetailsId { get; set; }

        public virtual RoomDetails RoomDetails { get; set; }
        public virtual ICollection<Reservation> Reservations { get; set; }


    }
}

﻿using HotelReservation.Core.DTOs.Auth;
using HotelReservation.Infrastructure.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Infrastructure.Data
{
    public class DataSeeder
    {
        private readonly ApplicationDbContext _DbContext;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _userRoleManager;
        public DataSeeder(ApplicationDbContext DbContext, UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> userRoleManager)
        {
            _DbContext = DbContext;
            _userManager = userManager;
            _userRoleManager = userRoleManager;
         }

        public  async Task SeedAsync(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();
            //add roles 
            var roles = new[] { "Admin", "Manager", "User" };
            await addRole(roles);
            //add users

            // Look for any students.
            if (!context.Users.Any())
            {
                //add admin
                ApplicationUser applicationUser = new ApplicationUser();
                applicationUser.UserName = "Admin";
                applicationUser.Email = "admin@gmail.com";
                applicationUser.FirstName = "admin";
                applicationUser.LastName = "User";
                applicationUser.PasswordHash = "P@$$w0rd";
                applicationUser.PhoneNumber = "2131315643";
                await addUser(applicationUser,"Admin");
                //add user 
                ApplicationUser User = new ApplicationUser();
                User.UserName = "User";
                User.Email = "user@gmail.com";
                User.FirstName = "User";
                User.LastName = "test";
                User.PasswordHash = "Pa$$w0rd";
                User.PhoneNumber = "2131315643";
                await addUser(User, "User");
            }

            if (!context.Rooms.Any())
            {
                Room room = new Room();
                room.RoomNumber = 1;
                room.RoomId=Guid.NewGuid().ToString();
                room.Title = "new room";
                room.Description = "description";
                room.RoomDetails = new RoomDetails();
                room.RoomDetails.RoomDetailsId = Guid.NewGuid().ToString();
                room.RoomDetails.Address = "alex";
                room.RoomDetails.RoomType = "single";
                room.RoomDetails.Description = "desc";
                context.Rooms.Add(room);
                context.SaveChanges();

                Room newroom = new Room();
                newroom.RoomNumber = 2;
                newroom.RoomId = Guid.NewGuid().ToString();
                newroom.Title = "new room";
                newroom.Description = "description";
                newroom.RoomDetails = new RoomDetails();
                newroom.RoomDetails.RoomDetailsId = Guid.NewGuid().ToString();
                newroom.RoomDetails.Address = "alex";
                newroom.RoomDetails.RoomType = "double";
                newroom.RoomDetails.Description = "desc";
                context.Rooms.Add(newroom);
                context.SaveChanges();
            }

        }
        public async Task addRole(string[] roles)
        {
            foreach (var role in roles)
            {
                if (!await _userRoleManager.RoleExistsAsync(role))
                {
                    await _userRoleManager.CreateAsync(new IdentityRole(role));
                }
            }

        }
        public async Task addUser(ApplicationUser applicationUser,string Role)
        {
            var result = await _userManager.CreateAsync(applicationUser, applicationUser.PasswordHash);
            if (result.Succeeded)
            {
                var user = await _userManager.FindByIdAsync(applicationUser.Id);
                if (user is not null || !await _userRoleManager.RoleExistsAsync(Role))
                {
                    IdentityResult identityResult = await _userManager.AddToRoleAsync(user, Role);
                }
            }

        }
    }
}

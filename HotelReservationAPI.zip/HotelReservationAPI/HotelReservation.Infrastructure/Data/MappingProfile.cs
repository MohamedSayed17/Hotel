﻿using AutoMapper;
using HotelReservation.Core.DTOs.Auth;
using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Infrastructure.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Infrastructure.Data
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<AuthModel, AuthModelDTO>().ReverseMap();
            CreateMap<RegisterModel, RegisterModelDTO>().ReverseMap();
            CreateMap<TokenRequestModel, TokenRequestModelDTO>().ReverseMap();
            CreateMap<ReservationDTO, Reservation>().ReverseMap();
            CreateMap<CustomerDTO, Customer>().ReverseMap();
            CreateMap<RoomDTO, Room>().ReverseMap();
            CreateMap<RoomDetailsDTO, RoomDetails>().ReverseMap();

        }
    }
}
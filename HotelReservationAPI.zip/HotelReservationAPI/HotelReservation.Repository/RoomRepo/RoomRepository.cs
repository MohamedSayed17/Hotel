﻿using AutoMapper;
using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Repository.RoomRepo
{
    public class RoomRepository :IRoomRepository
    {
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly IMapper autoMapper;
        public RoomRepository(ApplicationDbContext applicationDbContext, IMapper mapper)
        {
            _applicationDbContext= applicationDbContext;
            autoMapper= mapper;
        }

        public List<RoomDTO> GetAllRooms()
        {
            List<Room> roomList=new List<Room>();
            List<RoomDTO> roomListDTO=new List<RoomDTO>();
             roomList = _applicationDbContext.Rooms.ToList();
            roomListDTO = autoMapper.Map<List<Room>, List<RoomDTO>>(roomList);          
            return roomListDTO;
        }

        public RoomDTO GetRoomIDByRoomNumer(int roomNumer)
        {
            Room room=new Room();
            RoomDTO roomDTO=new RoomDTO();
            string roomID = string.Empty;
            try
            {
               room=_applicationDbContext.Rooms.Where(r=>r.RoomNumber==roomNumer).FirstOrDefault();
                roomDTO = autoMapper.Map<Room, RoomDTO>(room);
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);
            }
            return roomDTO;
        }
 
    }
}

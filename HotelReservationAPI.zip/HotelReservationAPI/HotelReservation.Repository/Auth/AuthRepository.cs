﻿using HotelReservation.Core;
using HotelReservation.Core.DTOs.Auth;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Infrastructure.Models;
using HotelReservationAPI.Helpers;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Repository.Auth
{
    public class AuthRepository : IAuthRepository
    {
        private readonly UserManager<ApplicationUser> _userManager;
         private readonly RoleManager<IdentityRole> _userRoleManager;
        private readonly JWTModel _jwt;
        public AuthRepository(UserManager<ApplicationUser> userManager,
            IOptions<JWTModel> jwt, RoleManager<IdentityRole> userRoleManager)
        {
            _userManager = userManager;
            _jwt = jwt.Value;
             _userRoleManager = userRoleManager;
        }
        public async Task<JwtSecurityToken> GenerateJWTToken(ApplicationUser user)
        {
            var userclaims = await _userManager.GetClaimsAsync(user);
            var userRoles = await _userManager.GetRolesAsync(user);
            var userRolesClaim = new List<Claim>();

            foreach (var role in userRoles)
            {
                userRolesClaim.Add(new Claim("role", role));
            }
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub,user.UserName),
                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Email,user.Email),
                new Claim("uid",user.Id),
            }
            .Union(userclaims)
            .Union(userRolesClaim);

            var symmetricSecurotyKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.key));
            var signingCredentials = new SigningCredentials(symmetricSecurotyKey, SecurityAlgorithms.HmacSha256);

            var jwtSecurityToken = new JwtSecurityToken(
                issuer: _jwt.Issuer,
                audience: _jwt.Audience,
                claims: claims,
                expires: DateTime.Now.AddDays(_jwt.DurationInDays),
                signingCredentials: signingCredentials
                );
            return jwtSecurityToken;
        }

        public async Task<AuthModelDTO> RegisterAsync(RegisterModelDTO model)
        {
            RoleModelDTO roleModelDTO = new RoleModelDTO();

            //validate userName if it exist
            if (await _userManager.FindByNameAsync(model.Username) is not null)
                return new AuthModelDTO { Message = "Username is already registered!" };

            var user = new ApplicationUser
            {
                UserName = model.Username,
                Email = model.Email,
                FirstName = model.FirstName,
                LastName = model.LastName
            };
            //create user
            var result = await _userManager.CreateAsync(user, model.Password);
           
             
            //check if the user Not created
            if (!result.Succeeded)
            {
                var errors = string.Empty;

                foreach (var error in result.Errors)
                    errors += $"{error.Description},";

                return new AuthModelDTO { Message = errors };
            }
            else
            {
                    var UserForRole = await _userManager.FindByIdAsync(user.Id);
                if (user is not null || !await _userRoleManager.RoleExistsAsync(Strings.UserRole))
                {
                    IdentityResult identityResult = await _userManager.AddToRoleAsync(user, Strings.UserRole);
                }
            }

            return new AuthModelDTO
            {
                Email = user.Email, 
                IsAuthenticated = true,
                Roles = new List<string> { "User" }, 
                Username = user.UserName,
                Message = "User Created Successfully!",
             };
        }

        public async Task<AuthModelDTO> GetTokenAsync(TokenRequestModelDTO model)
        {
            var authModel = new AuthModelDTO();

            var user = await _userManager.FindByNameAsync(model.UserName);

            if (user is null || !await _userManager.CheckPasswordAsync(user, model.Password))
            {
                authModel.Message = "Email or Password is incorrect!";
                return authModel;
            }

            var jwtSecurityToken = await GenerateJWTToken(user);

            authModel.IsAuthenticated = true;
            authModel.Token = new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
            authModel.Email = user.Email;
            authModel.Username = user.UserName;
            authModel.ExpiresOn = jwtSecurityToken.ValidTo;
            return authModel;
        }

        public async Task<string> AddRoleAsync(string userName,string Role)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user is null || !await _userRoleManager.RoleExistsAsync(Role))
                return "Invalid user ID or Role";

            if (await _userManager.IsInRoleAsync(user, Role))
                return "User already assigned to this role";

            var result = await _userManager.AddToRoleAsync(user, Role);

            return result.Succeeded ? Strings.AssignRoleMessage : "Sonething went wrong";
        }
    }
}

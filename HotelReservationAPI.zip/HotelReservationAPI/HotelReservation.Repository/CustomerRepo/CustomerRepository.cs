﻿using AutoMapper;
 using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.Interfaces.Repositories;
using HotelReservation.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelReservation.Repository.CustomerRepo
{
    public class CustomerRepository :ICustomerRepository
    {
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly IMapper autoMapper;
        public CustomerRepository(ApplicationDbContext applicationDbContext, IMapper mapper)
        {
            _applicationDbContext = applicationDbContext;
            autoMapper = mapper;
        }

        public List<CustomerDTO> GetCustomers()
        {
            List<CustomerDTO> customerDTOs = new List<CustomerDTO>();
            List<Customer> customers = new List<Customer>();
            customers = _applicationDbContext.Customers.ToList();
            customerDTOs = autoMapper.Map<List<Customer>, List<CustomerDTO>>(customers);
            return customerDTOs;
        }
    }
}

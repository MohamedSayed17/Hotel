﻿using HotelReservation.Core.DTOs.Reservation;
using HotelReservation.Core.Interfaces.Repositories;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelReservation.Infrastructure.Models;
using HotelReservation.Core;
using System.Web.Http;
using HotelReservation.Core.DTOs.Response;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace HotelReservation.Repository.ReservationRepo
{
    public class ReservationRepository : IReservationRepository
    {
        private readonly IMapper autoMapper;
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly IRoomRepository _roomRepository;
        public ReservationRepository(IMapper _mapper, ApplicationDbContext applicationDbContext, IRoomRepository roomRepository )
        {
            autoMapper = _mapper;
            _roomRepository = roomRepository;
            _applicationDbContext = applicationDbContext;
        }

        public ResponseBaseDTO CreateReservation( ReservationDTO reservationDTO)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            reservationDTO.ReservationId = Guid.NewGuid().ToString();
            reservationDTO.Customer.Id= Guid.NewGuid().ToString();
            if (!IsRoomAvailable(reservationDTO.RoomId))
            {
                reservationDTO.RoomId=reservationDTO.RoomId;
            }
            else
            {
                responseBaseDTO.Message = "Room Not available please choose another room";
                responseBaseDTO.StatusCode = System.Net.HttpStatusCode.NotFound;
                 return responseBaseDTO;
            }  
             reservationDTO.Status = GetStatusByDates(reservationDTO.startDate, reservationDTO.endDate);
            Reservation reservation = autoMapper.Map<ReservationDTO, Reservation>(reservationDTO);
            _applicationDbContext.Reservations.Add(reservation);
            _applicationDbContext.SaveChanges();
            responseBaseDTO.Message = "Reservation Done Successfully";
            responseBaseDTO.StatusCode = System.Net.HttpStatusCode.OK;
            return responseBaseDTO;
        }
        public ResponseBaseDTO UpdateReservation(string ReservationId,ReservationDTO reservationDTO)
        {
            ResponseBaseDTO responseBaseDTO = new ResponseBaseDTO();
            Reservation reservation = _applicationDbContext.Reservations.Where(r => r.ReservationId == ReservationId).FirstOrDefault();
            reservationDTO.ReservationId = ReservationId;
            if (reservation != null)
            {
                reservationDTO.CustomerId = reservation.CustomerId;
                reservationDTO.Customer.Id = reservation.CustomerId;
                reservationDTO.Status = GetStatusByDates(reservationDTO.startDate, reservationDTO.endDate);

                reservation = autoMapper.Map<ReservationDTO, Reservation>(reservationDTO);
            }
            _applicationDbContext.Update(reservation);
              
            _applicationDbContext.SaveChanges();
            responseBaseDTO.Message = "Reservation Updated Successfully";
            responseBaseDTO.StatusCode = System.Net.HttpStatusCode.OK;
                return responseBaseDTO;
        }
        public string GetStatusByDates(DateTime startDate, DateTime endDate)
        {
            string status = string.Empty;
            if(startDate > DateTime.Now)
            {
                status = Strings.Upcoming;
            }
            else
            {
                status = Strings.Past;
            }
            return status;
        }
        public void DeleteReservation(string id)
        {
            Reservation reservation = _applicationDbContext.Reservations.Where(l => l.ReservationId == id).FirstOrDefault();
            _applicationDbContext.Reservations.Remove(reservation);
            _applicationDbContext.SaveChanges();
        }
        public bool IsRoomAvailable(string roomId)
        {
             return _applicationDbContext.Reservations.Any(r => r.RoomId == roomId);
        }
        public void EditReservation(int id)
        {
            throw new NotImplementedException();
        }

        public List<ReservationVMDTO> GetReservationsByCustomerId(string customerId)
        {
            var reservation = (from r in _applicationDbContext.Reservations
                               join ro in _applicationDbContext.Rooms on r.RoomId equals ro.RoomId
                               join rod in _applicationDbContext.RoomDetails on ro.RoomId equals rod.Room.RoomId
                               where r.CustomerId == customerId
                               select new ReservationVMDTO
                               {
                                   RoomTitle = ro.Title,
                                   startDate = r.startDate,
                                   endDate = r.endDate,
                                   Status = r.startDate>DateTime.Now?Strings.Upcoming:Strings.Past,
                                   RoomType = rod.RoomType,
                                   RoomNumber= ro.RoomNumber,
                                   RoomDescription=ro.Description,
                               }).ToList();
            return reservation;
        }

        public List<ReservationDTO> SearchReservations(string title)
        {
            throw new NotImplementedException();
        }

        public List<ReservationDTO> GetReservations()
        {
            List<ReservationDTO> reservationDTOs= new List<ReservationDTO>();
            List<Reservation> reservations= new List<Reservation>();
            reservations = _applicationDbContext.Reservations.ToList();
            reservationDTOs = autoMapper.Map<List<Reservation>, List<ReservationDTO>>(reservations);
            return reservationDTOs;
        }
    }
}

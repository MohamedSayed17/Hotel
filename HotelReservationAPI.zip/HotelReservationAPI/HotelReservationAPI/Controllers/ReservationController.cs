﻿using HotelReservation.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelReservationAPI.Controllers
{
   
    public class ReservationController : Controller
    {
        public ReservationController() { }
        [HttpGet]
        [Route("GetReservation")]
        [Authorize]
        public IActionResult GetReservations()
        {
            try
            {
                //var reservations = _calendarService.GetReservationsByFieldId(fieldId);
                return Ok();
            }
            catch (ApplicationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

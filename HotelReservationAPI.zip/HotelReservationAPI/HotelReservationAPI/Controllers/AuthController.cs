﻿using HotelReservation.Core.DTOs.Auth;
 using HotelReservation.Infrastructure.Models;
 using Microsoft.AspNetCore.Mvc;

namespace HotelReservationAPI.Controllers
{
    public class AuthController : Controller
    {
        // private readonly IAuthService _authService;
        public AuthController()
        {
            // _authService=authService;
        }

        //[HttpPost("register")]
        //public async Task<ActionResult> Registerasync([FromBody] RegisterModelDTO model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //  //  var result = await _authService.Register(model);
        //    //if (!result.IsAuthenticated)
        //    //{
        //    //    return BadRequest(result.Message);
        //    //}

        //    //return Ok(result);
        //}
        //[HttpPost("Login")]
        //public async Task<ActionResult> GenerateTokenasync([FromBody] TokenRequestModelDTO model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    var result = await _authService.GetUserToken(model);
        //    if (!result.IsAuthenticated)
        //    {
        //        return BadRequest(result.Message);
        //    }

        //    return Ok(result);
        //}
    
    }
}
